// Estoy creando un shared cfg

export default {
  //urlBasePath: "sample", // deprecated
  requestUrlPath: "http://localhost:3000/request.cmd",
  uploadImagesUrlPath: "http://localhost:3000/upload.cmd",
  catalogImagesUrlPath: "http://localhost:3000/catalog-images",
  // catalogImagesUrlBigPath: "big",
  // catalogImagesUrlSmallPath: "small",
}

// requestFilePath => requesteEgExp, uploadFilePath => uploadUrlPath, loadAllComponentsUrlPath => loadAllComponentsUrlPath