export default {
  requestUrlPath: "request.cmd",
  uploadImagesUrlPath: "upload.cmd",
  catalogImagesUrlPath: "catalog-images"
}