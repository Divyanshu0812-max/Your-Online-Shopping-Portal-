
textEditorSaved=''; //This var saves the textEditor (external application) data to not be deteleted each time