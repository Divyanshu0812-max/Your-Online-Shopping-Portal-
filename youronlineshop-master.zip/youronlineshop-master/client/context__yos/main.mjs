import {bodyView} from './body.mjs'
import {startView} from './start.mjs'

await startView(bodyView)