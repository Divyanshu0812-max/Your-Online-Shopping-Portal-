Themes
======


# Introduction

Parece que usamos aqui algo similar a Prebound methods pattern, quizá mejor hacerlo tal cual este sistema, revisar.

https://python-patterns.guide/python/prebound-methods/
