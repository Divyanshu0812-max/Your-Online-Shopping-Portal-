Database queries
=========================

# Introduction

We have seen at reqres.md how how the request is performed. In this text we will see more in detail how to perform the database queries.

# Client

nodes.js and request.js

# Server
