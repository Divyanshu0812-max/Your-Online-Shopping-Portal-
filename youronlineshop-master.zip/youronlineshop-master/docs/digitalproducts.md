Digital Products
================

Proyecto:
Para hacer los digital goods yo haria lo siguiente:
- añadiria una colección parecida a la de images
Esta colección estaría conectada con el producto.
- Añadiria un servico como el de load images para subirla, se crearia otra carpeta.
- se mostraria el link a al producto en el layout onsucceded. Puede ser un link que de alguna manera funcione de forma temporal en el servidor, se puede añadir un campo caducidad.
