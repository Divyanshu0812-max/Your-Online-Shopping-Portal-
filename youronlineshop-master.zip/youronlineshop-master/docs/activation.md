Activate selected Feature
===============

## Intro

Links active by the module activelauncher.js. thisNode.highLightElement

## Procedure