Versioning
==========

## Introduction

The version of the software appears at file version.txt. The characters "+beta" will appear after the version number when the version is ahead version number but it is not stable or significative.