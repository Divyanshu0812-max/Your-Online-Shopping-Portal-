Coding standards
----------------

## Methos arguments

The arguments of the methos would be usually following an order. The rule is that it would start from more general arguments to more specific ones. Also the element in the argument that is more likely the main argument would also be last. If there are arguments that are compulsive and that arguments are not related to the main function computation purpose these arguments would appear first. Optional arguments will apear last.

## Naming

Names would be usually also comming from less specific elemnt to more specific one.