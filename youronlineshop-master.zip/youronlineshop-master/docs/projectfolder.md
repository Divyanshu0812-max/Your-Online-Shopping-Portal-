Project folder schema
===============