Guide to write extensions
=========================

## Intro

Extensions are also contexts, or a mix of contexts and layouts.

## Specific files and custom code

Any specific element of a extension (for code files) must include a comment with words extension_name custom. This way will be easy to identify any custom element from an extension. This is crucial for updating to latest software.