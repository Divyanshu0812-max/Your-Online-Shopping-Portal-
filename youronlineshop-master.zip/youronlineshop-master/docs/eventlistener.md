Event listener pattern
=======================

# Introduction

There are implementatinos of event listener pattern at DOM and Node.js. However these two are different implementations and there are some specificities in our system that would recomend to develop our own approach. However it is a good practique to review these aproaches: browser EventTarget , Node.js EventEmitter

