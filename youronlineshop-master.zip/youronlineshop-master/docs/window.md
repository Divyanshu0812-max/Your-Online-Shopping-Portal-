Window elements
===============

## Introduction

We will see the elements that produce changes at the browser window element. We think it is important to notice these elements because we have the posibility to change the application without reloading the browser page. That means some browser window status and elements could keep the same, so we should be aware of these status in order to launch a new application.