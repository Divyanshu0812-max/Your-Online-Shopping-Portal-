Errors sends by Api: string value sentinel for errors

Problem

with comes with api we are just passing string values, how to detect therefore an error?