dbmanager

Se podria crear una base de datos que se carga al inicio en memoria como con los contexts. Esta seria la base de datos del propio programa y las otras serian las de mongodb