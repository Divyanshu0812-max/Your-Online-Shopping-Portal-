Themes
=======

We can create themes by copying the layouts main folder and changing the app_instance/cfg/custom.mjs layoutsPath.
